﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace OOPP
{
    public partial class 재고관리 : Form
    {
        private MySqlConnection connection;

        public 재고관리()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1000, 650);
            labletime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            // MySQL 데이터베이스 연결 문자열 설정
            string connectionString = "Server=cs-dept.esm.kr;Port=23306;Database=webprog;Uid=webprog;Pwd=0571;";
            connection = new MySqlConnection(connectionString);

            // 폼 로드 이벤트 핸들러에 데이터 조회 메서드 호출 추가
            this.Load += 재고관리_Load;
        }

        // 폼 로드 이벤트 핸들러
        private void 재고관리_Load(object sender, EventArgs e)
        {
            // 데이터 조회 메서드 호출
            LoadInventoryData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string 이름 = textBox1.Text;
            string 수량Text = textBox2.Text;
            int 수량;

            // 수량 값이 숫자로 변환 가능한지 확인
            if (int.TryParse(수량Text, out 수량))
            {
                DateTime 유통기한 = dateTimePicker1.Value;

                // 데이터베이스 연결 오픈
                connection.Open();

                // 데이터 삽입 쿼리 작성
                string query = "INSERT INTO inventory (이름, 수량, 유통기한) VALUES (@이름, @수량, @유통기한)";

                // 데이터 삽입 명령 객체 생성
                MySqlCommand command = new MySqlCommand(query, connection);

                // 파라미터 설정
                command.Parameters.AddWithValue("@이름", 이름);
                command.Parameters.AddWithValue("@수량", 수량);
                command.Parameters.AddWithValue("@유통기한", 유통기한);

                // 데이터 삽입 실행
                command.ExecuteNonQuery();

                // 데이터베이스 연결 닫기
                connection.Close();

                // 데이터 재로드
                LoadInventoryData();

                // 입력 필드 초기화
                textBox1.Clear();
                textBox2.Clear();
            }
            else
            {
                // 수량이 숫자로 변환되지 않는 경우에 대한 처리
                MessageBox.Show("유효한 수량을 입력하세요.", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        // 데이터 조회 메서드
        private void LoadInventoryData()
        {
            // 데이터베이스 연결 오픈
            connection.Open();

            // 데이터 조회 쿼리 작성
            string query = "SELECT 이름, 수량, 유통기한 FROM inventory";

            // 데이터 조회 명령 객체 생성
            MySqlCommand command = new MySqlCommand(query, connection);

            // 데이터 어댑터와 데이터셋 생성
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataSet dataset = new DataSet();

            // 데이터 어댑터를 사용하여 데이터셋 채우기
            adapter.Fill(dataset);

            // DataGridView에 데이터셋 바인딩
            dataGridView1.DataSource = dataset.Tables[0];

            // 데이터베이스 연결 닫기
            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 선택된 행을 확인
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // 선택된 행의 인덱스 가져오기
                int rowIndex = dataGridView1.SelectedRows[0].Index;

                // 선택된 행에서 이름 값 가져오기
                string 이름 = dataGridView1.Rows[rowIndex].Cells["이름"].Value.ToString();

                // 데이터베이스 연결 오픈
                connection.Open();

                // 삭제 쿼리 작성
                string query = "DELETE FROM inventory WHERE 이름 = @이름";

                // 삭제 명령 객체 생성
                MySqlCommand command = new MySqlCommand(query, connection);

                // 파라미터 설정
                command.Parameters.AddWithValue("@이름", 이름);

                // 삭제 실행
                command.ExecuteNonQuery();

                // 데이터베이스 연결 닫기
                connection.Close();

                // 데이터 재로드
                LoadInventoryData();
            }
            else
            {
                // 선택된 행이 없는 경우에 대한 처리
                MessageBox.Show("삭제할 재고를 선택하세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // 메뉴 폼 인스턴스 생성
            메뉴 form메뉴 = new 메뉴();

            // 현재 폼을 닫고 메뉴 폼을 보여줌
            this.Hide();
            form메뉴.Show();
        }

    }
}
