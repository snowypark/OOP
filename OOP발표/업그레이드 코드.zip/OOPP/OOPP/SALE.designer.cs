﻿namespace testest
{
    partial class SALE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.판매 = new System.Windows.Forms.Panel();
            this.dataGridViewOrder = new System.Windows.Forms.DataGridView();
            this.받을금액 = new System.Windows.Forms.Label();
            this.labelTotalPrice = new System.Windows.Forms.Label();
            this.labelReceivedAmount = new System.Windows.Forms.Label();
            this.받은금액 = new System.Windows.Forms.Label();
            this.buttonCardPayment = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabBeverage = new System.Windows.Forms.TabPage();
            this.CappuccinoHot = new System.Windows.Forms.Button();
            this.CafeLatteHot = new System.Windows.Forms.Button();
            this.AddShot = new System.Windows.Forms.Button();
            this.CappuccinoIce = new System.Windows.Forms.Button();
            this.CafeLatteIce = new System.Windows.Forms.Button();
            this.MacchiatoIce = new System.Windows.Forms.Button();
            this.MacchiatoHot = new System.Windows.Forms.Button();
            this.AmericanoIce = new System.Windows.Forms.Button();
            this.AmericanoHot = new System.Windows.Forms.Button();
            this.tabDessert = new System.Windows.Forms.TabPage();
            this.Chocolatecake = new System.Windows.Forms.Button();
            this.Muffin = new System.Windows.Forms.Button();
            this.Macaron = new System.Windows.Forms.Button();
            this.Cheesecake = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.totalmoney = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnmenu = new System.Windows.Forms.Button();
            this.labletime = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.판매.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOrder)).BeginInit();
            this.tabControl.SuspendLayout();
            this.tabBeverage.SuspendLayout();
            this.tabDessert.SuspendLayout();
            this.SuspendLayout();
            // 
            // 판매
            // 
            this.판매.BackColor = System.Drawing.Color.White;
            this.판매.Controls.Add(this.dataGridViewOrder);
            this.판매.Controls.Add(this.받을금액);
            this.판매.Controls.Add(this.labelTotalPrice);
            this.판매.Controls.Add(this.labelReceivedAmount);
            this.판매.Controls.Add(this.받은금액);
            this.판매.Controls.Add(this.buttonCardPayment);
            this.판매.Controls.Add(this.button15);
            this.판매.Controls.Add(this.tabControl);
            this.판매.Location = new System.Drawing.Point(181, 50);
            this.판매.Name = "판매";
            this.판매.Size = new System.Drawing.Size(791, 499);
            this.판매.TabIndex = 5;
            // 
            // dataGridViewOrder
            // 
            this.dataGridViewOrder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewOrder.Location = new System.Drawing.Point(18, 60);
            this.dataGridViewOrder.Name = "dataGridViewOrder";
            this.dataGridViewOrder.RowTemplate.Height = 23;
            this.dataGridViewOrder.Size = new System.Drawing.Size(344, 267);
            this.dataGridViewOrder.TabIndex = 11;
            // 
            // 받을금액
            // 
            this.받을금액.AutoSize = true;
            this.받을금액.Font = new System.Drawing.Font("나눔고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.받을금액.Location = new System.Drawing.Point(32, 369);
            this.받을금액.Name = "받을금액";
            this.받을금액.Size = new System.Drawing.Size(68, 17);
            this.받을금액.TabIndex = 4;
            this.받을금액.Text = "받을 금액";
            // 
            // labelTotalPrice
            // 
            this.labelTotalPrice.AutoSize = true;
            this.labelTotalPrice.Font = new System.Drawing.Font("나눔고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelTotalPrice.Location = new System.Drawing.Point(168, 369);
            this.labelTotalPrice.Name = "labelTotalPrice";
            this.labelTotalPrice.Size = new System.Drawing.Size(17, 17);
            this.labelTotalPrice.TabIndex = 3;
            this.labelTotalPrice.Text = "0";
            // 
            // labelReceivedAmount
            // 
            this.labelReceivedAmount.AutoSize = true;
            this.labelReceivedAmount.Font = new System.Drawing.Font("나눔고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labelReceivedAmount.Location = new System.Drawing.Point(168, 427);
            this.labelReceivedAmount.Name = "labelReceivedAmount";
            this.labelReceivedAmount.Size = new System.Drawing.Size(17, 17);
            this.labelReceivedAmount.TabIndex = 2;
            this.labelReceivedAmount.Text = "0";
            // 
            // 받은금액
            // 
            this.받은금액.AutoSize = true;
            this.받은금액.Font = new System.Drawing.Font("나눔고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.받은금액.Location = new System.Drawing.Point(32, 427);
            this.받은금액.Name = "받은금액";
            this.받은금액.Size = new System.Drawing.Size(68, 17);
            this.받은금액.TabIndex = 1;
            this.받은금액.Text = "받은 금액";
            // 
            // buttonCardPayment
            // 
            this.buttonCardPayment.Font = new System.Drawing.Font("나눔고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.buttonCardPayment.Location = new System.Drawing.Point(641, 427);
            this.buttonCardPayment.Name = "buttonCardPayment";
            this.buttonCardPayment.Size = new System.Drawing.Size(94, 50);
            this.buttonCardPayment.TabIndex = 9;
            this.buttonCardPayment.Text = "결제 하기";
            this.buttonCardPayment.UseVisualStyleBackColor = true;
            this.buttonCardPayment.Click += new System.EventHandler(this.buttonCardPayment_Click);
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("나눔고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button15.Location = new System.Drawing.Point(641, 352);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(94, 50);
            this.button15.TabIndex = 9;
            this.button15.Text = "전체 취소";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabBeverage);
            this.tabControl.Controls.Add(this.tabDessert);
            this.tabControl.Font = new System.Drawing.Font("나눔고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabControl.Location = new System.Drawing.Point(368, 32);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(401, 295);
            this.tabControl.TabIndex = 0;
            // 
            // tabBeverage
            // 
            this.tabBeverage.Controls.Add(this.CappuccinoHot);
            this.tabBeverage.Controls.Add(this.CafeLatteHot);
            this.tabBeverage.Controls.Add(this.AddShot);
            this.tabBeverage.Controls.Add(this.CappuccinoIce);
            this.tabBeverage.Controls.Add(this.CafeLatteIce);
            this.tabBeverage.Controls.Add(this.MacchiatoIce);
            this.tabBeverage.Controls.Add(this.MacchiatoHot);
            this.tabBeverage.Controls.Add(this.AmericanoIce);
            this.tabBeverage.Controls.Add(this.AmericanoHot);
            this.tabBeverage.Location = new System.Drawing.Point(4, 28);
            this.tabBeverage.Name = "tabBeverage";
            this.tabBeverage.Padding = new System.Windows.Forms.Padding(3);
            this.tabBeverage.Size = new System.Drawing.Size(393, 263);
            this.tabBeverage.TabIndex = 0;
            this.tabBeverage.Text = "음료";
            this.tabBeverage.UseVisualStyleBackColor = true;
            // 
            // CappuccinoHot
            // 
            this.CappuccinoHot.Location = new System.Drawing.Point(269, 6);
            this.CappuccinoHot.Name = "CappuccinoHot";
            this.CappuccinoHot.Size = new System.Drawing.Size(94, 50);
            this.CappuccinoHot.TabIndex = 9;
            this.CappuccinoHot.Text = "카푸치노(HOT)";
            this.CappuccinoHot.UseVisualStyleBackColor = true;
            this.CappuccinoHot.Click += new System.EventHandler(this.CappuccinoHot_Click);
            // 
            // CafeLatteHot
            // 
            this.CafeLatteHot.Location = new System.Drawing.Point(148, 6);
            this.CafeLatteHot.Name = "CafeLatteHot";
            this.CafeLatteHot.Size = new System.Drawing.Size(94, 50);
            this.CafeLatteHot.TabIndex = 9;
            this.CafeLatteHot.Text = "카페라떼(HOT)";
            this.CafeLatteHot.UseVisualStyleBackColor = true;
            this.CafeLatteHot.Click += new System.EventHandler(this.CafeLatteHot_Click);
            // 
            // AddShot
            // 
            this.AddShot.Location = new System.Drawing.Point(269, 200);
            this.AddShot.Name = "AddShot";
            this.AddShot.Size = new System.Drawing.Size(94, 50);
            this.AddShot.TabIndex = 9;
            this.AddShot.Text = "샷 추가(500)";
            this.AddShot.UseVisualStyleBackColor = true;
            // 
            // CappuccinoIce
            // 
            this.CappuccinoIce.Location = new System.Drawing.Point(269, 71);
            this.CappuccinoIce.Name = "CappuccinoIce";
            this.CappuccinoIce.Size = new System.Drawing.Size(94, 50);
            this.CappuccinoIce.TabIndex = 9;
            this.CappuccinoIce.Text = "카푸치노(ICE)";
            this.CappuccinoIce.UseVisualStyleBackColor = true;
            this.CappuccinoIce.Click += new System.EventHandler(this.CappuccinoIce_Click);
            // 
            // CafeLatteIce
            // 
            this.CafeLatteIce.Location = new System.Drawing.Point(148, 71);
            this.CafeLatteIce.Name = "CafeLatteIce";
            this.CafeLatteIce.Size = new System.Drawing.Size(94, 50);
            this.CafeLatteIce.TabIndex = 9;
            this.CafeLatteIce.Text = "카페라떼(ICE)";
            this.CafeLatteIce.UseVisualStyleBackColor = true;
            this.CafeLatteIce.Click += new System.EventHandler(this.CafeLatteIce_Click);
            // 
            // MacchiatoIce
            // 
            this.MacchiatoIce.Location = new System.Drawing.Point(18, 200);
            this.MacchiatoIce.Name = "MacchiatoIce";
            this.MacchiatoIce.Size = new System.Drawing.Size(94, 50);
            this.MacchiatoIce.TabIndex = 9;
            this.MacchiatoIce.Text = "마끼아또(ICE)";
            this.MacchiatoIce.UseVisualStyleBackColor = true;
            this.MacchiatoIce.Click += new System.EventHandler(this.MacchiatoIce_Click);
            // 
            // MacchiatoHot
            // 
            this.MacchiatoHot.Font = new System.Drawing.Font("나눔고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.MacchiatoHot.Location = new System.Drawing.Point(18, 136);
            this.MacchiatoHot.Name = "MacchiatoHot";
            this.MacchiatoHot.Size = new System.Drawing.Size(94, 50);
            this.MacchiatoHot.TabIndex = 9;
            this.MacchiatoHot.Text = "마끼아또\r\n(HOT)";
            this.MacchiatoHot.UseVisualStyleBackColor = true;
            this.MacchiatoHot.Click += new System.EventHandler(this.MacchiatoHot_Click);
            // 
            // AmericanoIce
            // 
            this.AmericanoIce.Location = new System.Drawing.Point(18, 71);
            this.AmericanoIce.Name = "AmericanoIce";
            this.AmericanoIce.Size = new System.Drawing.Size(94, 50);
            this.AmericanoIce.TabIndex = 9;
            this.AmericanoIce.Text = "아메리카노(ICE)";
            this.AmericanoIce.UseVisualStyleBackColor = true;
            this.AmericanoIce.Click += new System.EventHandler(this.AmericanoIce_Click);
            // 
            // AmericanoHot
            // 
            this.AmericanoHot.Location = new System.Drawing.Point(18, 6);
            this.AmericanoHot.Name = "AmericanoHot";
            this.AmericanoHot.Size = new System.Drawing.Size(94, 50);
            this.AmericanoHot.TabIndex = 9;
            this.AmericanoHot.Text = "아메리카노(HOT)";
            this.AmericanoHot.UseVisualStyleBackColor = true;
            // 
            // tabDessert
            // 
            this.tabDessert.Controls.Add(this.Chocolatecake);
            this.tabDessert.Controls.Add(this.Muffin);
            this.tabDessert.Controls.Add(this.Macaron);
            this.tabDessert.Controls.Add(this.Cheesecake);
            this.tabDessert.Location = new System.Drawing.Point(4, 28);
            this.tabDessert.Name = "tabDessert";
            this.tabDessert.Padding = new System.Windows.Forms.Padding(3);
            this.tabDessert.Size = new System.Drawing.Size(393, 263);
            this.tabDessert.TabIndex = 1;
            this.tabDessert.Text = "디저트";
            this.tabDessert.UseVisualStyleBackColor = true;
            // 
            // Chocolatecake
            // 
            this.Chocolatecake.Location = new System.Drawing.Point(20, 97);
            this.Chocolatecake.Name = "Chocolatecake";
            this.Chocolatecake.Size = new System.Drawing.Size(94, 50);
            this.Chocolatecake.TabIndex = 9;
            this.Chocolatecake.Text = "초코케이크";
            this.Chocolatecake.UseVisualStyleBackColor = true;
            this.Chocolatecake.Click += new System.EventHandler(this.Chocolatecake_Click);
            // 
            // Muffin
            // 
            this.Muffin.Location = new System.Drawing.Point(145, 97);
            this.Muffin.Name = "Muffin";
            this.Muffin.Size = new System.Drawing.Size(94, 50);
            this.Muffin.TabIndex = 9;
            this.Muffin.Text = "머핀";
            this.Muffin.UseVisualStyleBackColor = true;
            this.Muffin.Click += new System.EventHandler(this.Muffin_Click);
            // 
            // Macaron
            // 
            this.Macaron.Location = new System.Drawing.Point(145, 18);
            this.Macaron.Name = "Macaron";
            this.Macaron.Size = new System.Drawing.Size(94, 50);
            this.Macaron.TabIndex = 9;
            this.Macaron.Text = "마카롱";
            this.Macaron.UseVisualStyleBackColor = true;
            this.Macaron.Click += new System.EventHandler(this.Macaron_Click);
            // 
            // Cheesecake
            // 
            this.Cheesecake.Location = new System.Drawing.Point(20, 18);
            this.Cheesecake.Name = "Cheesecake";
            this.Cheesecake.Size = new System.Drawing.Size(94, 50);
            this.Cheesecake.TabIndex = 9;
            this.Cheesecake.Text = "치즈케이크";
            this.Cheesecake.UseVisualStyleBackColor = true;
            this.Cheesecake.Click += new System.EventHandler(this.Cheesecake_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.Font = new System.Drawing.Font("나눔고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button1.Location = new System.Drawing.Point(12, 509);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 40);
            this.button1.TabIndex = 2;
            this.button1.Text = "판매";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // totalmoney
            // 
            this.totalmoney.AutoSize = true;
            this.totalmoney.Font = new System.Drawing.Font("나눔고딕", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.totalmoney.Location = new System.Drawing.Point(33, 310);
            this.totalmoney.Name = "totalmoney";
            this.totalmoney.Size = new System.Drawing.Size(22, 21);
            this.totalmoney.TabIndex = 6;
            this.totalmoney.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("나눔고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(31, 258);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 24);
            this.label2.TabIndex = 7;
            this.label2.Text = "판매 금액";
            // 
            // btnmenu
            // 
            this.btnmenu.Location = new System.Drawing.Point(12, 12);
            this.btnmenu.Name = "btnmenu";
            this.btnmenu.Size = new System.Drawing.Size(141, 63);
            this.btnmenu.TabIndex = 10;
            this.btnmenu.Text = "메뉴";
            this.btnmenu.UseVisualStyleBackColor = true;
            this.btnmenu.Click += new System.EventHandler(this.btnmenu_Click);
            // 
            // labletime
            // 
            this.labletime.AutoSize = true;
            this.labletime.Location = new System.Drawing.Point(799, 23);
            this.labletime.Name = "labletime";
            this.labletime.Size = new System.Drawing.Size(57, 12);
            this.labletime.TabIndex = 18;
            this.labletime.Text = "현재 날짜";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("나눔고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(707, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 19);
            this.label4.TabIndex = 17;
            this.label4.Text = "현재 날짜";
            // 
            // SALE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.labletime);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnmenu);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.totalmoney);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.판매);
            this.Name = "SALE";
            this.Text = "판매창cs";
            this.판매.ResumeLayout(false);
            this.판매.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOrder)).EndInit();
            this.tabControl.ResumeLayout(false);
            this.tabBeverage.ResumeLayout(false);
            this.tabDessert.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel 판매;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabBeverage;
        private System.Windows.Forms.TabPage tabDessert;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label 받을금액;
        private System.Windows.Forms.Label labelTotalPrice;
        private System.Windows.Forms.Label labelReceivedAmount;
        private System.Windows.Forms.Label 받은금액;
        private System.Windows.Forms.Button AmericanoHot;
        private System.Windows.Forms.Button buttonCardPayment;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button CappuccinoHot;
        private System.Windows.Forms.Button CafeLatteHot;
        private System.Windows.Forms.Button AddShot;
        private System.Windows.Forms.Button CappuccinoIce;
        private System.Windows.Forms.Button CafeLatteIce;
        private System.Windows.Forms.Button MacchiatoIce;
        private System.Windows.Forms.Button MacchiatoHot;
        private System.Windows.Forms.Button AmericanoIce;
        private System.Windows.Forms.Button Chocolatecake;
        private System.Windows.Forms.Button Muffin;
        private System.Windows.Forms.Button Macaron;
        private System.Windows.Forms.Button Cheesecake;
        private System.Windows.Forms.DataGridView dataGridViewOrder;
        private System.Windows.Forms.Label totalmoney;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnmenu;
        private System.Windows.Forms.Label labletime;
        private System.Windows.Forms.Label label4;
    }
}