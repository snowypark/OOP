﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace OOPP
{
    public partial class 매출관리 : Form
    {
        private MySqlConnection connection;
        private decimal totalSales; // 총 매출을 저장하는 변수

        public 매출관리()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1000, 650);
            labletime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            // MySQL 데이터베이스 연결 문자열 설정
            string connectionString = "Server=cs-dept.esm.kr;Port=23306;Database=webprog;Uid=webprog;Pwd=0571;";
            connection = new MySqlConnection(connectionString);

            // 폼 로드 이벤트 핸들러에 데이터 조회 메서드 호출 추가
            this.Load += 매출관리_Load;
        }

        // 폼 로드 이벤트 핸들러
        private void 매출관리_Load(object sender, EventArgs e)
        {
            // 데이터 조회 메서드 호출
            LoadSalesData();
        }

        // 데이터 조회 메서드
        private void LoadSalesData()
        {
            // 데이터베이스 연결 오픈
            connection.Open();

            // 데이터 조회 쿼리 작성
            string query = "SELECT 날짜, 금액 FROM Sales";

            // 데이터 조회 명령 객체 생성
            MySqlCommand command = new MySqlCommand(query, connection);

            // 데이터 어댑터와 데이터셋 생성
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataSet dataset = new DataSet();

            // 데이터 어댑터를 사용하여 데이터셋 채우기
            adapter.Fill(dataset);

            // DataGridView에 데이터셋 바인딩
            dataGridView1.DataSource = dataset.Tables[0];

            // 데이터베이스 연결 닫기
            connection.Close();

            // 총 매출 계산
            CalculateTotalSales();
        }

        // 총 매출 계산 메서드
        private void CalculateTotalSales()
        {
            totalSales = 0; // 총 매출 초기화

            // DataGridView의 각 행을 순회하며 금액을 더함
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.Cells["금액"].Value != null)
                {
                    decimal 금액 = Convert.ToDecimal(row.Cells["금액"].Value);
                    totalSales += 금액;
                }
            }

            // 총 매출을 라벨에 표시
            labelTotalSales.Text = "총 매출: " + totalSales.ToString("C");
        }


        private void button3_Click_1(object sender, EventArgs e)
        {
            // 메뉴 폼 인스턴스 생성
            메뉴 form메뉴 = new 메뉴();

            // 현재 폼을 닫고 메뉴 폼을 보여줌
            this.Hide();
            form메뉴.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            DateTime 날짜 = dateTimePicker1.Value;
            string 금액Text = textBox2.Text;
            decimal 금액;

            // 금액 값이 숫자로 변환 가능한지 확인
            if (decimal.TryParse(금액Text, out 금액))
            {
                // 데이터베이스 연결 오픈
                connection.Open();

                // 데이터 삽입 쿼리 작성
                string query = "INSERT INTO Sales (날짜, 금액) VALUES (@날짜, @금액)";

                // 데이터 삽입 명령 객체 생성
                MySqlCommand command = new MySqlCommand(query, connection);

                // 파라미터 설정
                command.Parameters.AddWithValue("@날짜", 날짜);
                command.Parameters.AddWithValue("@금액", 금액);

                // 데이터 삽입 실행
                command.ExecuteNonQuery();

                // 데이터베이스 연결 닫기
                connection.Close();

                // 데이터 재로드
                LoadSalesData();

                // 입력 필드 초기화
                textBox2.Clear();
            }
            else
            {
                // 금액이 숫자로 변환되지 않는 경우에 대한 처리
                MessageBox.Show("유효한 금액을 입력하세요.", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            // 선택된 행을 확인
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // 선택된 행의 인덱스 가져오기
                int rowIndex = dataGridView1.SelectedRows[0].Index;

                // 선택된 행에서 날짜 값 가져오기
                DateTime 날짜 = Convert.ToDateTime(dataGridView1.Rows[rowIndex].Cells["날짜"].Value);
                decimal 금액 = Convert.ToDecimal(dataGridView1.Rows[rowIndex].Cells["금액"].Value);

                // 데이터베이스 연결 오픈
                connection.Open();

                // 삭제 쿼리 작성
                string query = "DELETE FROM Sales WHERE 날짜 = @날짜 AND 금액 = @금액";

                // 삭제 명령 객체 생성
                MySqlCommand command = new MySqlCommand(query, connection);

                // 파라미터 설정
                command.Parameters.AddWithValue("@날짜", 날짜);
                command.Parameters.AddWithValue("@금액", 금액);

                // 삭제 실행
                command.ExecuteNonQuery();

                // 데이터베이스 연결 닫기
                connection.Close();

                // 데이터 재로드
                LoadSalesData();
            }
            else
            {
                // 선택된 행이 없는 경우에 대한 처리
                MessageBox.Show("삭제할 매출을 선택하세요.", "확인필요", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

    }
}

