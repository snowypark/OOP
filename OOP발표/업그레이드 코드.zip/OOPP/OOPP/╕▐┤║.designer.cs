﻿namespace OOPP
{
    partial class 메뉴
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.재고관리 = new System.Windows.Forms.Button();
            this.tablebtn = new System.Windows.Forms.Button();
            this.btninform = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.salebtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(360, 356);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 31);
            this.button1.TabIndex = 0;
            this.button1.Text = "종료";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // 재고관리
            // 
            this.재고관리.Font = new System.Drawing.Font("나눔고딕", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.재고관리.Location = new System.Drawing.Point(47, 168);
            this.재고관리.Name = "재고관리";
            this.재고관리.Size = new System.Drawing.Size(130, 50);
            this.재고관리.TabIndex = 1;
            this.재고관리.Text = "재고 관리";
            this.재고관리.UseVisualStyleBackColor = true;
            this.재고관리.Click += new System.EventHandler(this.재고관리_Click);
            // 
            // tablebtn
            // 
            this.tablebtn.Font = new System.Drawing.Font("나눔고딕", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tablebtn.Location = new System.Drawing.Point(270, 57);
            this.tablebtn.Name = "tablebtn";
            this.tablebtn.Size = new System.Drawing.Size(130, 50);
            this.tablebtn.TabIndex = 2;
            this.tablebtn.Text = "테이블사용";
            this.tablebtn.UseVisualStyleBackColor = true;
            this.tablebtn.Click += new System.EventHandler(this.tablebtn_Click);
            // 
            // btninform
            // 
            this.btninform.Font = new System.Drawing.Font("나눔고딕", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btninform.Location = new System.Drawing.Point(47, 284);
            this.btninform.Name = "btninform";
            this.btninform.Size = new System.Drawing.Size(130, 50);
            this.btninform.TabIndex = 3;
            this.btninform.Text = "고객센터";
            this.btninform.UseVisualStyleBackColor = true;
            this.btninform.Click += new System.EventHandler(this.btninform_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("나눔고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button2.Location = new System.Drawing.Point(270, 168);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(130, 50);
            this.button2.TabIndex = 4;
            this.button2.Text = "체크리스트";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // salebtn
            // 
            this.salebtn.Font = new System.Drawing.Font("나눔고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.salebtn.Location = new System.Drawing.Point(47, 57);
            this.salebtn.Name = "salebtn";
            this.salebtn.Size = new System.Drawing.Size(130, 50);
            this.salebtn.TabIndex = 5;
            this.salebtn.Text = "판매";
            this.salebtn.UseVisualStyleBackColor = true;
            this.salebtn.Click += new System.EventHandler(this.salebtn_Click);
            // 
            // 메뉴
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(461, 399);
            this.Controls.Add(this.salebtn);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btninform);
            this.Controls.Add(this.tablebtn);
            this.Controls.Add(this.재고관리);
            this.Controls.Add(this.button1);
            this.Name = "메뉴";
            this.Text = "메뉴";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button 재고관리;
        private System.Windows.Forms.Button tablebtn;
        private System.Windows.Forms.Button btninform;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button salebtn;
    }
}