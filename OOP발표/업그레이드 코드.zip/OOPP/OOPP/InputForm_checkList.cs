﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace OOPP

{
    public partial class InputForm_checkList : Form
    {
        public string NewItem { get; private set; }

        public InputForm_checkList()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1000, 650);
            OK_checkList.Click += OK_checkList_Click;
        }

        private void OK_checkList_Click(object sender, EventArgs e)
        {
            NewItem = check_item.Text;
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
