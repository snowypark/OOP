﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;

namespace OOPP
{
    public partial class login : Form
    {
        // MySQL 데이터베이스 연결 설정
        string connectionString = "Server=cs-dept.esm.kr;Port=23306;Database=webprog;Uid=webprog;Pwd=0571;";

        public login()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1000,650);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                // 사용자 인증을 위한 쿼리 실행
                string query = "SELECT COUNT(*) FROM users WHERE username = @username AND password = @password";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@username", username);
                command.Parameters.AddWithValue("@password", password);

                int count = Convert.ToInt32(command.ExecuteScalar());

                if (count > 0)
                {
                    // 로그인 성공
                    MessageBox.Show("로그인 성공!");

                    // 메뉴 폼 인스턴스 생성
                    메뉴 form메뉴 = new 메뉴();
                    this.StartPosition = FormStartPosition.Manual;
                    this.Location = new Point(1000, 650);

                    // 현재 폼 숨기고 메뉴 폼을 보여줌
                    this.Hide();
                    form메뉴.Show();
                }
            
                else
                {
                    // 로그인 실패
                    MessageBox.Show("로그인 실패!");
                }
            }
        }

        private void 종료_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // register 폼 인스턴스 생성 및 표시
            register formRegister = new register();
            formRegister.ShowDialog();
        }
    }
}
