﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using testest;

namespace OOPP
{
    public partial class 메뉴 : Form
    {
       

        public bool isButton1Clicked;
        public bool isButton2Clicked;
        public bool isButton3Clicked;
        public bool isButton4Clicked;
        public bool isButton5Clicked;
        public bool isButton6Clicked;

        public 메뉴()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1000, 650);
        }
      
        private void button1_Click(object sender, EventArgs e)
        {
            // 프로그램 종료
            Application.Exit();
        }

        private void 재고관리_Click(object sender, EventArgs e)
        {
            // 재고관리 폼 인스턴스 생성
            재고관리 form재고관리 = new 재고관리();

            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1000, 650);

            // 현재 폼을 닫고 재고관리 폼을 보여줌
            this.Hide();
            form재고관리.Show();
        }

        private void tablebtn_Click(object sender, EventArgs e)
        {
            // 테이블예약 폼 인스턴스를 가져옴
            테이블예약 form테이블예약 = 테이블예약.GetInstance();

            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1000, 650);

            // 현재 폼을 닫고 테이블예약 폼을 보여줌
            this.Hide();
            form테이블예약.Show();
        }

       

        private void btninform_Click(object sender, EventArgs e)
        {
            // 고객센터 폼 인스턴스 생성
            고객센터 form고객센터 = new 고객센터();

            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1000, 650);
            // 현재 폼을 닫고 고객센터 폼을 보여줌
            this.Hide();
            form고객센터.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 체크리스트 폼 인스턴스 생성
            체크리스트 form체크리스트 = new 체크리스트();

            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1000, 650);
            // 현재 폼을 닫고 체크리스트 폼을 보여줌
            this.Hide();
            form체크리스트.Show();
        }

        private void salebtn_Click(object sender, EventArgs e)
        {
            // SALE 폼 인스턴스 생성
            SALE formSale = new SALE();

            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1000, 650);
            // 현재 폼을 닫고 SALE 폼을 보여줌
            this.Hide();
            formSale.Show();
        }

    }
}
