﻿using OOPP;
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace testest
{
    public partial class SALE : Form
    {
        private DataTable orderTable; // 데이터를 저장할 DataTable 변수
        private decimal totalSales; // 매출을 저장할 변수

        public SALE()
        {
            InitializeComponent();
            this.Load += SALE_Load; // 폼의 Load 이벤트 핸들러 설정

            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1000, 650);
            labletime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }

        private void SALE_Load(object sender, EventArgs e)
        {
            // 기존에 추가되어 있는 열 삭제
            dataGridViewOrder.Columns.Clear();

            // 데이터 그리드 뷰에 열(Column) 추가
            AddColumn("Menu", "메뉴");
            AddColumn("Quantity", "수량");
            AddColumn("Price", "가격");

            // 데이터 테이블 초기화
            orderTable = new DataTable();
            orderTable.Columns.Add("메뉴");
            orderTable.Columns.Add("수량");
            orderTable.Columns.Add("가격");

            // 데이터 그리드 뷰에 데이터 테이블 바인딩
            dataGridViewOrder.DataSource = orderTable;

            // 기존 탭의 버튼과 이벤트 핸들러 연결
            AmericanoHot.Click += AmericanoHot_Click;

            // sales 테이블 생성
            CreateSalesTable();
        }

        private void AddColumn(string columnName, string headerText)
        {
            if (dataGridViewOrder.Columns[columnName] == null)
            {
                dataGridViewOrder.Columns.Add(columnName, headerText);
            }
        }

        private void AmericanoHot_Click(object sender, EventArgs e)
        {
            string menuName = "아메리카노(HOT)"; // 메뉴 이름
            int quantity = 1; // 수량
            decimal price = 2000; // 가격

            // 이미 주문 테이블에 해당 메뉴가 있는지 확인
            DataRow existingRow = orderTable.AsEnumerable()
                .FirstOrDefault(row => row.Field<string>("메뉴") == menuName);

            if (existingRow != null)
            {
                // 이미 해당 메뉴가 주문되어 있으면 수량을 증가시킴
                existingRow["수량"] = Convert.ToInt32(existingRow["수량"]) + quantity;
                existingRow["가격"] = Convert.ToInt32(existingRow["수량"]) * price;
            }
            else
            {
                // 주문 테이블에 새로운 데이터 추가
                DataRow newRow = orderTable.NewRow();
                newRow["메뉴"] = menuName;
                newRow["수량"] = quantity;
                newRow["가격"] = price;
                orderTable.Rows.Add(newRow);
            }

            // 받을 금액 업데이트
            decimal totalPrice = CalculateTotalPrice();
            labelTotalPrice.Text = totalPrice.ToString();
        }

        private void CreateSalesTable()
        {
            // sales 테이블 생성 코드
            // ...
        }

        private decimal CalculateTotalPrice()
        {
            decimal totalPrice = 0;
            foreach (DataRow row in orderTable.Rows)
            {
                decimal price = Convert.ToDecimal(row["가격"]);
                totalPrice += price;
            }
            return totalPrice;
        }

        private void buttonCardPayment_Click(object sender, EventArgs e)
        {
            decimal totalPrice = CalculateTotalPrice();

            // 받을 금액 업데이트
            labelReceivedAmount.Text = totalPrice.ToString();

            DialogResult result = MessageBox.Show("카드 결제 하시겠습니까?", "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                // 매출을 계산하여 저장합니다.
                totalSales += totalPrice;
                // 매출을 저장하는 코드
                SaveTotalSales(totalSales);
                // 받은 금액을 총 주문 금액으로 설정
                labelReceivedAmount.Text = "0";
                // totalMoney 라벨에 매출 금액 표시
                totalmoney.Text = totalSales.ToString();
                MessageBox.Show("결제가 완료되었습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // 결제가 완료된 후에 labelTotalPrice 초기화
                labelTotalPrice.Text = "0";

                // dataGridViewOrder 초기화
                orderTable.Rows.Clear();
            }
        }


        private void SaveTotalSales(decimal totalSales)
        {
            // 매출을 저장하는 코드
            // ...
        }

        // 전체 취소버튼
        private void button15_Click(object sender, EventArgs e)
        {
            // '받을 금액' 레이블 초기화
            labelReceivedAmount.Text = "0";

            // dataGridViewOrder 초기화
            orderTable.Rows.Clear();

            // 받을 금액 업데이트
            decimal totalPrice = CalculateTotalPrice();
            labelTotalPrice.Text = totalPrice.ToString();
        }


        //메뉴들-----------------------------
        private void AmericanoIce_Click(object sender, EventArgs e)
        {
            string menuName = "아메리카노(ICE)"; // 메뉴 이름
            int quantity = 1; // 수량
            decimal price = 2500; // 가격

            // 이미 주문 테이블에 해당 메뉴가 있는지 확인
            DataRow existingRow = orderTable.AsEnumerable()
                .FirstOrDefault(row => row.Field<string>("메뉴") == menuName);

            if (existingRow != null)
            {
                // 이미 해당 메뉴가 주문되어 있으면 수량을 증가시킴
                existingRow["수량"] = Convert.ToInt32(existingRow["수량"]) + quantity;
                existingRow["가격"] = Convert.ToInt32(existingRow["수량"]) * price;
            }
            else
            {
                // 주문 테이블에 새로운 데이터 추가
                DataRow newRow = orderTable.NewRow();
                newRow["메뉴"] = menuName;
                newRow["수량"] = quantity;
                newRow["가격"] = price;
                orderTable.Rows.Add(newRow);
            }

            // 받을 금액 업데이트
            decimal totalPrice = CalculateTotalPrice();
            labelTotalPrice.Text = totalPrice.ToString();
        }

      

        private void CafeLatteHot_Click(object sender, EventArgs e)
        {
            string menuName = "카페라떼(HOT)"; // 메뉴 이름
            int quantity = 1; // 수량
            decimal price = 4000; // 가격

            // 이미 주문 테이블에 해당 메뉴가 있는지 확인
            DataRow existingRow = orderTable.AsEnumerable()
                .FirstOrDefault(row => row.Field<string>("메뉴") == menuName);

            if (existingRow != null)
            {
                // 이미 해당 메뉴가 주문되어 있으면 수량을 증가시킴
                existingRow["수량"] = Convert.ToInt32(existingRow["수량"]) + quantity;
                existingRow["가격"] = Convert.ToInt32(existingRow["수량"]) * price;
            }
            else
            {
                // 주문 테이블에 새로운 데이터 추가
                DataRow newRow = orderTable.NewRow();
                newRow["메뉴"] = menuName;
                newRow["수량"] = quantity;
                newRow["가격"] = price;
                orderTable.Rows.Add(newRow);
            }

            // 받을 금액 업데이트
            decimal totalPrice = CalculateTotalPrice();
            labelTotalPrice.Text = totalPrice.ToString();
        }
             

        private void CafeLatteIce_Click(object sender, EventArgs e)
        {
            string menuName = "카페라떼(ICE)"; // 메뉴 이름
            int quantity = 1; // 수량
            decimal price = 4000; // 가격

            // 이미 주문 테이블에 해당 메뉴가 있는지 확인
            DataRow existingRow = orderTable.AsEnumerable()
                .FirstOrDefault(row => row.Field<string>("메뉴") == menuName);

            if (existingRow != null)
            {
                // 이미 해당 메뉴가 주문되어 있으면 수량을 증가시킴
                existingRow["수량"] = Convert.ToInt32(existingRow["수량"]) + quantity;
                existingRow["가격"] = Convert.ToInt32(existingRow["수량"]) * price;
            }
            else
            {
                // 주문 테이블에 새로운 데이터 추가
                DataRow newRow = orderTable.NewRow();
                newRow["메뉴"] = menuName;
                newRow["수량"] = quantity;
                newRow["가격"] = price;
                orderTable.Rows.Add(newRow);
            }

            // 받을 금액 업데이트
            decimal totalPrice = CalculateTotalPrice();
            labelTotalPrice.Text = totalPrice.ToString();
        }


        private void CappuccinoHot_Click(object sender, EventArgs e)
        {
            string menuName = "카푸치노(HOT)"; // 메뉴 이름
            int quantity = 1; // 수량
            decimal price = 4000; // 가격

            // 이미 주문 테이블에 해당 메뉴가 있는지 확인
            DataRow existingRow = orderTable.AsEnumerable()
                .FirstOrDefault(row => row.Field<string>("메뉴") == menuName);

            if (existingRow != null)
            {
                // 이미 해당 메뉴가 주문되어 있으면 수량을 증가시킴
                existingRow["수량"] = Convert.ToInt32(existingRow["수량"]) + quantity;
                existingRow["가격"] = Convert.ToInt32(existingRow["수량"]) * price;
            }
            else
            {
                // 주문 테이블에 새로운 데이터 추가
                DataRow newRow = orderTable.NewRow();
                newRow["메뉴"] = menuName;
                newRow["수량"] = quantity;
                newRow["가격"] = price;
                orderTable.Rows.Add(newRow);
            }

            // 받을 금액 업데이트
            decimal totalPrice = CalculateTotalPrice();
            labelTotalPrice.Text = totalPrice.ToString();
        }
          
        private void CappuccinoIce_Click(object sender, EventArgs e)
        {
            string menuName = "카푸치노(ICE)"; // 메뉴 이름
            int quantity = 1; // 수량
            decimal price = 4000; // 가격

            // 이미 주문 테이블에 해당 메뉴가 있는지 확인
            DataRow existingRow = orderTable.AsEnumerable()
                .FirstOrDefault(row => row.Field<string>("메뉴") == menuName);

            if (existingRow != null)
            {
                // 이미 해당 메뉴가 주문되어 있으면 수량을 증가시킴
                existingRow["수량"] = Convert.ToInt32(existingRow["수량"]) + quantity;
                existingRow["가격"] = Convert.ToInt32(existingRow["수량"]) * price;
            }
            else
            {
                // 주문 테이블에 새로운 데이터 추가
                DataRow newRow = orderTable.NewRow();
                newRow["메뉴"] = menuName;
                newRow["수량"] = quantity;
                newRow["가격"] = price;
                orderTable.Rows.Add(newRow);
            }

            // 받을 금액 업데이트
            decimal totalPrice = CalculateTotalPrice();
            labelTotalPrice.Text = totalPrice.ToString();
        }

    

        private void MacchiatoHot_Click(object sender, EventArgs e)
        {
            string menuName = "카라멜 마끼아또(HOT)"; // 메뉴 이름
            int quantity = 1; // 수량
            decimal price = 4000; // 가격

            // 이미 주문 테이블에 해당 메뉴가 있는지 확인
            DataRow existingRow = orderTable.AsEnumerable()
                .FirstOrDefault(row => row.Field<string>("메뉴") == menuName);

            if (existingRow != null)
            {
                // 이미 해당 메뉴가 주문되어 있으면 수량을 증가시킴
                existingRow["수량"] = Convert.ToInt32(existingRow["수량"]) + quantity;
                existingRow["가격"] = Convert.ToInt32(existingRow["수량"]) * price;
            }
            else
            {
                // 주문 테이블에 새로운 데이터 추가
                DataRow newRow = orderTable.NewRow();
                newRow["메뉴"] = menuName;
                newRow["수량"] = quantity;
                newRow["가격"] = price;
                orderTable.Rows.Add(newRow);
            }

            // 받을 금액 업데이트
            decimal totalPrice = CalculateTotalPrice();
            labelTotalPrice.Text = totalPrice.ToString();
        }

        private void MacchiatoIce_Click(object sender, EventArgs e)
        {
            string menuName = "카라멜 마끼아또(ICE)"; // 메뉴 이름
            int quantity = 1; // 수량
            decimal price = 4000; // 가격

            // 이미 주문 테이블에 해당 메뉴가 있는지 확인
            DataRow existingRow = orderTable.AsEnumerable()
                .FirstOrDefault(row => row.Field<string>("메뉴") == menuName);

            if (existingRow != null)
            {
                // 이미 해당 메뉴가 주문되어 있으면 수량을 증가시킴
                existingRow["수량"] = Convert.ToInt32(existingRow["수량"]) + quantity;
                existingRow["가격"] = Convert.ToInt32(existingRow["수량"]) * price;
            }
            else
            {
                // 주문 테이블에 새로운 데이터 추가
                DataRow newRow = orderTable.NewRow();
                newRow["메뉴"] = menuName;
                newRow["수량"] = quantity;
                newRow["가격"] = price;
                orderTable.Rows.Add(newRow);
            }

            // 받을 금액 업데이트
            decimal totalPrice = CalculateTotalPrice();
            labelTotalPrice.Text = totalPrice.ToString();
        }

        private void Cheesecake_Click(object sender, EventArgs e)
        {
            string menuName = "치즈 케이크"; // 메뉴 이름
            int quantity = 1; // 수량
            decimal price = 6000; // 가격

            // 이미 주문 테이블에 해당 메뉴가 있는지 확인
            DataRow existingRow = orderTable.AsEnumerable()
                .FirstOrDefault(row => row.Field<string>("메뉴") == menuName);

            if (existingRow != null)
            {
                // 이미 해당 메뉴가 주문되어 있으면 수량을 증가시킴
                existingRow["수량"] = Convert.ToInt32(existingRow["수량"]) + quantity;
                existingRow["가격"] = Convert.ToInt32(existingRow["수량"]) * price;
            }
            else
            {
                // 주문 테이블에 새로운 데이터 추가
                DataRow newRow = orderTable.NewRow();
                newRow["메뉴"] = menuName;
                newRow["수량"] = quantity;
                newRow["가격"] = price;
                orderTable.Rows.Add(newRow);
            }

            // 받을 금액 업데이트
            decimal totalPrice = CalculateTotalPrice();
            labelTotalPrice.Text = totalPrice.ToString();
        }

        private void Chocolatecake_Click(object sender, EventArgs e)
        {
            string menuName = "초코 케이크"; // 메뉴 이름
            int quantity = 1; // 수량
            decimal price = 6000; // 가격

            // 이미 주문 테이블에 해당 메뉴가 있는지 확인
            DataRow existingRow = orderTable.AsEnumerable()
                .FirstOrDefault(row => row.Field<string>("메뉴") == menuName);

            if (existingRow != null)
            {
                // 이미 해당 메뉴가 주문되어 있으면 수량을 증가시킴
                existingRow["수량"] = Convert.ToInt32(existingRow["수량"]) + quantity;
                existingRow["가격"] = Convert.ToInt32(existingRow["수량"]) * price;
            }
            else
            {
                // 주문 테이블에 새로운 데이터 추가
                DataRow newRow = orderTable.NewRow();
                newRow["메뉴"] = menuName;
                newRow["수량"] = quantity;
                newRow["가격"] = price;
                orderTable.Rows.Add(newRow);
            }

            // 받을 금액 업데이트
            decimal totalPrice = CalculateTotalPrice();
            labelTotalPrice.Text = totalPrice.ToString();
        }

        private void Macaron_Click(object sender, EventArgs e)
        {
            string menuName = "마카롱"; // 메뉴 이름
            int quantity = 1; // 수량
            decimal price = 3000; // 가격

            // 이미 주문 테이블에 해당 메뉴가 있는지 확인
            DataRow existingRow = orderTable.AsEnumerable()
                .FirstOrDefault(row => row.Field<string>("메뉴") == menuName);

            if (existingRow != null)
            {
                // 이미 해당 메뉴가 주문되어 있으면 수량을 증가시킴
                existingRow["수량"] = Convert.ToInt32(existingRow["수량"]) + quantity;
                existingRow["가격"] = Convert.ToInt32(existingRow["수량"]) * price;
            }
            else
            {
                // 주문 테이블에 새로운 데이터 추가
                DataRow newRow = orderTable.NewRow();
                newRow["메뉴"] = menuName;
                newRow["수량"] = quantity;
                newRow["가격"] = price;
                orderTable.Rows.Add(newRow);
            }

            // 받을 금액 업데이트
            decimal totalPrice = CalculateTotalPrice();
            labelTotalPrice.Text = totalPrice.ToString();
        }

        private void Muffin_Click(object sender, EventArgs e)
        {
            string menuName = "머핀"; // 메뉴 이름
            int quantity = 1; // 수량
            decimal price = 3500; // 가격

            // 이미 주문 테이블에 해당 메뉴가 있는지 확인
            DataRow existingRow = orderTable.AsEnumerable()
                .FirstOrDefault(row => row.Field<string>("메뉴") == menuName);

            if (existingRow != null)
            {
                // 이미 해당 메뉴가 주문되어 있으면 수량을 증가시킴
                existingRow["수량"] = Convert.ToInt32(existingRow["수량"]) + quantity;
                existingRow["가격"] = Convert.ToInt32(existingRow["수량"]) * price;
            }
            else
            {
                // 주문 테이블에 새로운 데이터 추가
                DataRow newRow = orderTable.NewRow();
                newRow["메뉴"] = menuName;
                newRow["수량"] = quantity;
                newRow["가격"] = price;
                orderTable.Rows.Add(newRow);
            }

            // 받을 금액 업데이트
            decimal totalPrice = CalculateTotalPrice();
            labelTotalPrice.Text = totalPrice.ToString();
        }

        private void btnmenu_Click(object sender, EventArgs e)
        {
            // 메뉴 폼 인스턴스 생성
            메뉴 formMenu = new 메뉴();

            // 현재 폼을 닫고 메뉴 폼을 보여줌
            this.Hide();
            formMenu.Show();
        }

    }
}
