﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOPP
{
    public partial class 고객센터 : Form
    {
        public 고객센터()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1000, 650);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // 메뉴 폼 인스턴스 생성
            메뉴 form메뉴 = new 메뉴();
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1000, 650);
            // 현재 폼을 닫고 메뉴 폼을 보여줌
            this.Hide();
            form메뉴.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
