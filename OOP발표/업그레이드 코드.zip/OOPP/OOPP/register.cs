﻿// register.cs

using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace OOPP
{
    public partial class register : Form
    {
        string connectionString = "Server=cs-dept.esm.kr;Port=23306;Database=webprog;Uid=webprog;Pwd=0571;";

        public register()
        {
            InitializeComponent(); 
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1000, 650);
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                // 중복된 사용자명인지 확인
                string checkQuery = "SELECT COUNT(*) FROM users WHERE username = @username";
                MySqlCommand checkCommand = new MySqlCommand(checkQuery, connection);
                checkCommand.Parameters.AddWithValue("@username", username);
                int existingUserCount = Convert.ToInt32(checkCommand.ExecuteScalar());

                if (existingUserCount > 0)
                {
                    MessageBox.Show("이미 존재하는 사용자명입니다. 다른 사용자명을 입력해주세요.");
                    return;
                }

                // 사용자 정보를 데이터베이스에 추가
                string insertQuery = "INSERT INTO users (username, password) VALUES (@username, @password)";
                MySqlCommand insertCommand = new MySqlCommand(insertQuery, connection);
                insertCommand.Parameters.AddWithValue("@username", username);
                insertCommand.Parameters.AddWithValue("@password", password);
                insertCommand.ExecuteNonQuery();

                MessageBox.Show("회원가입이 완료되었습니다. 로그인해주세요.");

                // 회원가입 폼 종료
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                // 중복된 사용자명인지 확인
                string checkQuery = "SELECT COUNT(*) FROM users WHERE username = @username";
                MySqlCommand checkCommand = new MySqlCommand(checkQuery, connection);
                checkCommand.Parameters.AddWithValue("@username", username);
                int existingUserCount = Convert.ToInt32(checkCommand.ExecuteScalar());

                if (existingUserCount > 0)
                {
                    MessageBox.Show("이미 존재하는 사용자명입니다. 다른 사용자명을 입력해주세요.");
                    return;
                }

                // 사용자 정보를 데이터베이스에 추가
                string insertQuery = "INSERT INTO users (username, password) VALUES (@username, @password)";
                MySqlCommand insertCommand = new MySqlCommand(insertQuery, connection);
                insertCommand.Parameters.AddWithValue("@username", username);
                insertCommand.Parameters.AddWithValue("@password", password);
                insertCommand.ExecuteNonQuery();

                MessageBox.Show("회원가입이 완료되었습니다. 로그인해주세요.");

                // 회원가입 폼 종료
                this.Close();
            }
        }

    }
}
