﻿namespace OOPP
{
    partial class InputForm_checkList
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button OK_checkList;
        private System.Windows.Forms.TextBox check_item;

        private void InitializeComponent()
        {
            this.OK_checkList = new System.Windows.Forms.Button();
            this.check_item = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // OK_checkList
            // 
            this.OK_checkList.Font = new System.Drawing.Font("나눔고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.OK_checkList.Location = new System.Drawing.Point(145, 126);
            this.OK_checkList.Name = "OK_checkList";
            this.OK_checkList.Size = new System.Drawing.Size(88, 38);
            this.OK_checkList.TabIndex = 0;
            this.OK_checkList.Text = "확인";
            this.OK_checkList.UseVisualStyleBackColor = true;
            this.OK_checkList.Click += new System.EventHandler(this.OK_checkList_Click);
            // 
            // check_item
            // 
            this.check_item.Font = new System.Drawing.Font("나눔고딕", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.check_item.Location = new System.Drawing.Point(59, 38);
            this.check_item.Name = "check_item";
            this.check_item.Size = new System.Drawing.Size(264, 29);
            this.check_item.TabIndex = 1;
            // 
            // InputForm_checkList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(376, 189);
            this.Controls.Add(this.check_item);
            this.Controls.Add(this.OK_checkList);
            this.Name = "InputForm_checkList";
            this.Text = "InputForm_checkList";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
