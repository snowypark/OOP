﻿using System.Windows.Forms;

namespace OOPP
{
    partial class 체크리스트
    {

        private System.ComponentModel.IContainer components = null;


        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.마감 = new System.Windows.Forms.Panel();
            this.CLOSE_textbox = new System.Windows.Forms.TextBox();
            this.OPEN_text = new System.Windows.Forms.TextBox();
            this.ADD_CLOSE_check = new System.Windows.Forms.Button();
            this.ADD_CHECK = new System.Windows.Forms.Button();
            this.CLOSE_check = new System.Windows.Forms.CheckedListBox();
            this.OPEN_check = new System.Windows.Forms.CheckedListBox();
            this.CLOSE = new System.Windows.Forms.Button();
            this.OPEN = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.labletime = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.마감.SuspendLayout();
            this.SuspendLayout();
            // 
            // 마감
            // 
            this.마감.BackColor = System.Drawing.Color.White;
            this.마감.Controls.Add(this.CLOSE_textbox);
            this.마감.Controls.Add(this.OPEN_text);
            this.마감.Controls.Add(this.ADD_CLOSE_check);
            this.마감.Controls.Add(this.ADD_CHECK);
            this.마감.Controls.Add(this.CLOSE_check);
            this.마감.Controls.Add(this.OPEN_check);
            this.마감.Controls.Add(this.CLOSE);
            this.마감.Controls.Add(this.OPEN);
            this.마감.Location = new System.Drawing.Point(181, 50);
            this.마감.Name = "마감";
            this.마감.Size = new System.Drawing.Size(791, 499);
            this.마감.TabIndex = 4;
            // 
            // CLOSE_textbox
            // 
            this.CLOSE_textbox.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.CLOSE_textbox.Font = new System.Drawing.Font("나눔고딕", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CLOSE_textbox.Location = new System.Drawing.Point(483, 28);
            this.CLOSE_textbox.Name = "CLOSE_textbox";
            this.CLOSE_textbox.Size = new System.Drawing.Size(200, 39);
            this.CLOSE_textbox.TabIndex = 3;
            this.CLOSE_textbox.Text = "마감 체크리스트";
            this.CLOSE_textbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.CLOSE_textbox.TextChanged += new System.EventHandler(this.OPEN_text_TextChanged);
            // 
            // OPEN_text
            // 
            this.OPEN_text.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.OPEN_text.Font = new System.Drawing.Font("나눔고딕", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.OPEN_text.Location = new System.Drawing.Point(103, 28);
            this.OPEN_text.Name = "OPEN_text";
            this.OPEN_text.Size = new System.Drawing.Size(200, 39);
            this.OPEN_text.TabIndex = 3;
            this.OPEN_text.Text = "오픈 체크리스트";
            this.OPEN_text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.OPEN_text.TextChanged += new System.EventHandler(this.OPEN_text_TextChanged);
            // 
            // ADD_CLOSE_check
            // 
            this.ADD_CLOSE_check.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ADD_CLOSE_check.Font = new System.Drawing.Font("나눔고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ADD_CLOSE_check.Location = new System.Drawing.Point(635, 353);
            this.ADD_CLOSE_check.Name = "ADD_CLOSE_check";
            this.ADD_CLOSE_check.Size = new System.Drawing.Size(75, 23);
            this.ADD_CLOSE_check.TabIndex = 2;
            this.ADD_CLOSE_check.Text = "추가";
            this.ADD_CLOSE_check.UseVisualStyleBackColor = false;
            // 
            // ADD_CHECK
            // 
            this.ADD_CHECK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ADD_CHECK.Font = new System.Drawing.Font("나눔고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ADD_CHECK.Location = new System.Drawing.Point(251, 353);
            this.ADD_CHECK.Name = "ADD_CHECK";
            this.ADD_CHECK.Size = new System.Drawing.Size(75, 23);
            this.ADD_CHECK.TabIndex = 2;
            this.ADD_CHECK.Text = "추가";
            this.ADD_CHECK.UseVisualStyleBackColor = false;
            // 
            // CLOSE_check
            // 
            this.CLOSE_check.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.CLOSE_check.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.CLOSE_check.Font = new System.Drawing.Font("나눔고딕 ExtraBold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CLOSE_check.FormattingEnabled = true;
            this.CLOSE_check.Items.AddRange(new object[] {
            "재고 확인",
            "테이블 정리",
            "그라인더 마감",
            "머신, 스팀 노즐 세척",
            "쓰레기 분리 배출",
            "진열대 정리",
            "야외 청소"});
            this.CLOSE_check.Location = new System.Drawing.Point(461, 86);
            this.CLOSE_check.Margin = new System.Windows.Forms.Padding(5);
            this.CLOSE_check.Name = "CLOSE_check";
            this.CLOSE_check.Size = new System.Drawing.Size(261, 301);
            this.CLOSE_check.TabIndex = 1;
            this.CLOSE_check.SelectedIndexChanged += new System.EventHandler(this.OPEN_CECHK_SelectedIndexChanged);
            // 
            // OPEN_check
            // 
            this.OPEN_check.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.OPEN_check.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.OPEN_check.Font = new System.Drawing.Font("나눔고딕 ExtraBold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.OPEN_check.FormattingEnabled = true;
            this.OPEN_check.Items.AddRange(new object[] {
            "조명 켜기",
            "머신 필터 세척",
            "테이블 청소",
            "야외 청소",
            "커피머신 켜기",
            "재고 확인",
            "재료 확인",
            "진열대 확인"});
            this.OPEN_check.Location = new System.Drawing.Point(77, 86);
            this.OPEN_check.Margin = new System.Windows.Forms.Padding(5);
            this.OPEN_check.Name = "OPEN_check";
            this.OPEN_check.Size = new System.Drawing.Size(261, 301);
            this.OPEN_check.TabIndex = 1;
            this.OPEN_check.SelectedIndexChanged += new System.EventHandler(this.OPEN_CECHK_SelectedIndexChanged);
            // 
            // CLOSE
            // 
            this.CLOSE.Font = new System.Drawing.Font("나눔고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CLOSE.Location = new System.Drawing.Point(531, 428);
            this.CLOSE.Name = "CLOSE";
            this.CLOSE.Size = new System.Drawing.Size(100, 30);
            this.CLOSE.TabIndex = 0;
            this.CLOSE.Text = "CLOSE";
            this.CLOSE.UseVisualStyleBackColor = true;
            // 
            // OPEN
            // 
            this.OPEN.Font = new System.Drawing.Font("나눔고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.OPEN.Location = new System.Drawing.Point(165, 428);
            this.OPEN.Name = "OPEN";
            this.OPEN.Size = new System.Drawing.Size(100, 30);
            this.OPEN.TabIndex = 0;
            this.OPEN.Text = "OPEN";
            this.OPEN.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button6.Font = new System.Drawing.Font("나눔고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button6.Location = new System.Drawing.Point(22, 509);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(130, 40);
            this.button6.TabIndex = 8;
            this.button6.Text = "마감";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("나눔고딕", 15.75F, System.Drawing.FontStyle.Bold);
            this.button3.Location = new System.Drawing.Point(12, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(141, 63);
            this.button3.TabIndex = 10;
            this.button3.Text = "메뉴";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // labletime
            // 
            this.labletime.AutoSize = true;
            this.labletime.Location = new System.Drawing.Point(755, 24);
            this.labletime.Name = "labletime";
            this.labletime.Size = new System.Drawing.Size(57, 12);
            this.labletime.TabIndex = 14;
            this.labletime.Text = "현재 날짜";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("나눔고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(663, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 19);
            this.label1.TabIndex = 13;
            this.label1.Text = "현재 날짜";
            // 
            // 체크리스트
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.labletime);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.마감);
            this.Name = "체크리스트";
            this.Text = "Form3";
            this.마감.ResumeLayout(false);
            this.마감.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel 마감;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.CheckedListBox OPEN_check;
        private System.Windows.Forms.Button CLOSE;
        private System.Windows.Forms.Button OPEN;
        private System.Windows.Forms.Button ADD_CHECK;
        private System.Windows.Forms.Button ADD_CLOSE_check;
        private System.Windows.Forms.CheckedListBox CLOSE_check;
        private System.Windows.Forms.TextBox OPEN_text;
        private TextBox CLOSE_textbox;
        private Button button3;
        private Label labletime;
        private Label label1;
    }
}
