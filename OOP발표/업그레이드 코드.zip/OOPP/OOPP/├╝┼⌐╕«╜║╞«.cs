﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOPP
{
    public partial class 체크리스트 : Form
    {
        private bool isButtonClicked = false; // 버튼 클릭 여부를 나타내는 변수
        private List<string> checkedItems = new List<string>(); // 체크된 항목들을 저장할 리스트

        // 체크리스트 폼의 인스턴스
        private static 체크리스트 instance;

        // 체크리스트 폼의 인스턴스를 가져오는 정적 메서드
        public static 체크리스트 GetInstance()
        {
            if (instance == null || instance.IsDisposed)
            {
                instance = new 체크리스트();

            }
            return instance;
        }

        public 체크리스트()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1000, 650);
            ADD_CHECK.Click += ADD_CHECK_Click; // ADD_CHECK 버튼과 이벤트 핸들러 연결
            ADD_CLOSE_check.Click += ADD_CLOSE_check_Click; // ADD_CLOSE_check 버튼과 이벤트 핸들러 연결
            OPEN.Click += OPEN_Click; // OPEN 버튼과 이벤트 핸들러 연결
            CLOSE.Click += CLOSE_Click; // CLOSE 버튼과 이벤트 핸들러 연결
            Load += 체크리스트_Load; // 폼 로드 이벤트 핸들러 연결
        }

        private void 체크리스트_Load(object sender, EventArgs e)
        {
            labletime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            // 체크리스트 폼이 로드될 때 초기화 코드 실행
            // 이곳에 초기화 코드를 작성합니다.
        }

        private void OPEN_CECHK_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ADD_CHECK_Click(object sender, EventArgs e)
        {
            InputForm_checkList inputForm = new InputForm_checkList();
            DialogResult result = inputForm.ShowDialog();

            if (result == DialogResult.OK)
            {
                string newItem = inputForm.NewItem;
                OPEN_check.Items.Add(newItem);

                // 체크된 항목 리스트에 추가
                if (OPEN_check.GetItemChecked(OPEN_check.Items.Count - 1))
                {
                    checkedItems.Add(newItem);
                }
            }
        }

        // ADD_CLOSE_check 버튼 클릭 이벤트 핸들러
        private void ADD_CLOSE_check_Click(object sender, EventArgs e)
        {
            InputForm_checkList inputForm = new InputForm_checkList();
            DialogResult result = inputForm.ShowDialog();

            if (result == DialogResult.OK)
            {
                string newItem = inputForm.NewItem;
                CLOSE_check.Items.Add(newItem);

                // 체크된 항목 리스트에 추가
                if (CLOSE_check.GetItemChecked(CLOSE_check.Items.Count - 1))
                {
                    checkedItems.Add(newItem);
                }
            }
        }

        // OPEN 버튼 클릭 이벤트 핸들러
        private void OPEN_Click(object sender, EventArgs e)
        {
            if (isButtonClicked)
            {
                // 버튼이 이미 클릭된 상태이면 원래 컬러로 변경
                OPEN.BackColor = SystemColors.Control;
                isButtonClicked = false;
            }
            else
            {
                // 버튼이 클릭되지 않은 상태이면 다른 컬러로 변경
                OPEN.BackColor = Color.DeepSkyBlue;
                isButtonClicked = true;
            }
        }

        // CLOSE 버튼 클릭 이벤트 핸들러
        private void CLOSE_Click(object sender, EventArgs e)
        {
            if (isButtonClicked)
            {
                // 버튼이 이미 클릭된 상태이면 원래 컬러로 변경
                CLOSE.BackColor = SystemColors.Control;
                isButtonClicked = false;
            }
            else
            {
                // 버튼이 클릭되지 않은 상태이면 다른 컬러로 변경
                CLOSE.BackColor = Color.DeepSkyBlue;
                isButtonClicked = true;
            }
        }

        private void OPEN_text_TextChanged(object sender, EventArgs e)
        {

        }

        // 체크된 항목들을 메뉴 폼에 전달하는 속성
        public List<string> CheckedItems
        {
            get { return checkedItems; }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // 메뉴 폼 인스턴스 생성
            메뉴 form메뉴 = new 메뉴();

            // 현재 폼을 닫고 메뉴 폼을 보여줌
            this.Hide();
            form메뉴.Show();
        }
    }
}
