﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace OOPP
{
    public partial class 테이블예약 : Form
    {
        // 테이블예약 폼의 인스턴스를 담을 정적 변수
        private static 테이블예약 instance;

        // 버튼 상태 변수들
        public static bool isButton1Clicked;
        public static bool isButton2Clicked;
        public static bool isButton3Clicked;
        public static bool isButton4Clicked;
        public static bool isButton5Clicked;
        public static bool isButton6Clicked;

        // 테이블예약 폼의 인스턴스를 가져오는 정적 메서드
        public static 테이블예약 GetInstance()
        {
            if (instance == null)
            {
                instance = new 테이블예약();
            }
            return instance;
        }

        private 테이블예약()
        {
            InitializeComponent();
            labletime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1000, 650);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ToggleButtonColor(button1, ref isButton1Clicked);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ToggleButtonColor(button2, ref isButton2Clicked);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ToggleButtonColor(button3, ref isButton3Clicked);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ToggleButtonColor(button4, ref isButton4Clicked);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ToggleButtonColor(button5, ref isButton5Clicked);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ToggleButtonColor(button6, ref isButton6Clicked);
        }

        private void ToggleButtonColor(Button button, ref bool isClicked)
        {
            if (isClicked)
            {
                button.BackColor = DefaultBackColor;
                isClicked = false;
            }
            else
            {
                button.BackColor = Color.Yellow;
                isClicked = true;
            }
        }

        private void menubtn_Click(object sender, EventArgs e)
        {
            // 메뉴 폼 인스턴스 생성
            메뉴 form메뉴 = new 메뉴();

            // 현재 테이블예약 폼의 상태 값을 가져와서 메뉴 폼으로 전달
            form메뉴.isButton1Clicked = isButton1Clicked;
            form메뉴.isButton2Clicked = isButton2Clicked;
            form메뉴.isButton3Clicked = isButton3Clicked;
            form메뉴.isButton4Clicked = isButton4Clicked;
            form메뉴.isButton5Clicked = isButton5Clicked;
            form메뉴.isButton6Clicked = isButton6Clicked;

            // 현재 폼을 닫고 메뉴 폼을 보여줌
            this.Hide();
            form메뉴.Show();
        }
    }
}
